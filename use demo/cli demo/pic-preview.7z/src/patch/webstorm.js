let event = {};
event.wheelDelta = "";
options.showStatusExtraStyle = "";
options.hideStatusExtraStyle = "";
options.showStatusExtraStyle = {};
options.hideStatusExtraStyle = {};
options.buttonHoverExtraStyle = {};